-- Run this in pgAdmin Query Tool on the college_events database.
ALTER TABLE events ADD COLUMN IF NOT EXISTS category   VARCHAR(40) DEFAULT 'General';
ALTER TABLE events ADD COLUMN IF NOT EXISTS event_time VARCHAR(20);
ALTER TABLE events ADD COLUMN IF NOT EXISTS organizer  VARCHAR(80);
ALTER TABLE events ADD COLUMN IF NOT EXISTS image_url  VARCHAR(255);

-- Removes the old sample events (and their registrations), then adds new ones.
TRUNCATE TABLE registrations, events RESTART IDENTITY;

INSERT INTO events (title,description,venue,event_date,event_time,organizer,category,capacity,image_url) VALUES
('TechNova 2026','The annual tech festival: project showcase, robotics arena, live coding contest and talks from industry guests. Open to all branches.','Main Auditorium','2026-11-20','10:00 AM','Department of Computer Science','Technical',300,'images/events/technova.svg'),
('Rangmanch Cultural Night','An evening of dance, drama, stand-up and live band performances by student clubs. Bring your friends and come early for seats.','Open Air Theatre','2026-11-27','6:00 PM','Cultural Committee','Cultural',500,'images/events/rangmanch.svg'),
('Inter-College Sports Meet','Track and field, football, cricket and kabaddi with teams from 12 colleges. Register to cheer or to join a team.','College Ground','2026-12-05','8:00 AM','Sports Council','Sports',400,'images/events/sports-meet.svg'),
('24-Hour Hackathon','Build a working prototype in 24 hours. Teams of 2 to 4, mentors on call, food and prizes for the top three projects.','Innovation Lab','2026-12-12','9:00 AM','Coding Club','Technical',120,'images/events/hackathon.svg'),
('Lens & Light Photography Exhibition','A gallery of student photography on campus life, travel and street scenes, with a short workshop on composition.','Art Gallery Hall','2026-12-15','11:00 AM','Photography Society','Arts',150,'images/events/photo-expo.svg'),
('Career Fair and Placement Drive','Meet recruiters from 25 companies, get resume feedback and attend short sessions on interview preparation.','Seminar Hall','2026-12-18','9:30 AM','Training and Placement Cell','Career',250,'images/events/career-fair.svg'),
('Blood Donation Camp','Donate blood with a certified medical team on site. Refreshments and a participation certificate for every donor.','Health Centre','2026-12-22','10:00 AM','NSS Unit','Social',100,'images/events/blood-camp.svg'),
('Winter Music Fest','Bands, solo artists and an open mic night to close the semester. Doors open 30 minutes before the first act.','Open Air Theatre','2027-01-09','5:30 PM','Music Club','Cultural',600,'images/events/music-fest.svg');
